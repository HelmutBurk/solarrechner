
/** Template: Solarrechner_final_bereinigt.js  *****
 ** calculation, pdfexport                     *****
 ** Version: 1.0.4                             *****
 ** ========================================== *****
 */


 document.addEventListener('DOMContentLoaded', () => {
  //document.getElementById("qmkwp").value = solarrechnerBackendSettings.qmkwp;  
  });

let chart;
let lineChart;

function runde100(x) {
  return Math.round(x / 100) * 100;
}
function runde10(x) {
  return Math.round(x / 10) * 10;
}

function berechne() {
  const qmkwp = parseFloat(solarrechnerBackendSettings.qmkwp);
  const spezifischerErtrag = parseFloat(solarrechnerBackendSettings.spezifischerErtrag);
  const erstellungskosten = parseFloat(solarrechnerBackendSettings.erstellungskosten);
  const flaeche = parseFloat(document.getElementById("dachflaeche").value);
  const ausrichtung = parseFloat(document.getElementById("ausrichtung").value);
  const verbrauch = parseFloat(document.getElementById("verbrauch").value);
  const strompreis = parseFloat(document.getElementById("strompreis").value);
  const batterie = parseFloat(document.getElementById("batterie").value);
  const batteriekosten = parseFloat(solarrechnerBackendSettings.batteriekosten);
  const foerderung = parseFloat(solarrechnerBackendSettings.einspeiseverguetung);
  const wartungProzent = parseFloat(solarrechnerBackendSettings.wartung);
  const fehlerBox = document.getElementById("error");

  fehlerBox.textContent = "";

  fetch('/wp-admin/admin-ajax.php?action=solarrechner_count')
    .then(response => response.json())
    .then(data => {
      const counterBox = document.getElementById("nutzungszaehler");
      if (counterBox) {
        counterBox.innerText = `Der Rechner wurde bisher ${data.data.count} Mal genutzt.`;
      }
    });

  if (flaeche <= 0 || verbrauch <= 0 || strompreis <= 0 || wartungProzent < 0) {
    fehlerBox.textContent = "Bitte alle Werte korrekt und größer als 0 eingeben.";
    return;
  }

  const kWp = flaeche / qmkwp;
  const ertrag = runde10(kWp * spezifischerErtrag * ausrichtung);

  let eigenverbrauchsanteil = 0.20;
  if (batterie > 0) {
    if (batterie <= 5) eigenverbrauchsanteil = 0.35;
    else if (batterie <= 7.5) eigenverbrauchsanteil = 0.40;
    else if (batterie <= 10) eigenverbrauchsanteil = 0.45;
    else if (batterie <= 12.5) eigenverbrauchsanteil = 0.50;
    else if (batterie <= 15) eigenverbrauchsanteil = 0.53;
  }

  const maxEV = verbrauch * 0.92;
  const eigenverbrauch = runde10(Math.min(ertrag * eigenverbrauchsanteil, maxEV));
  const einspeisung = runde10(ertrag - eigenverbrauch);
  const autarkie = Math.min((eigenverbrauch / verbrauch) * 100, 92);
  const ersparnis = runde10(eigenverbrauch * (strompreis / 100));
  const foerderungEur = runde10(einspeisung * (foerderung / 100));
  const co2 = runde10(ertrag * 0.6);
  const kostenGesamt = runde10(kWp * erstellungskosten + batterie * batteriekosten);
  const wartungKosten = runde10(kostenGesamt * (wartungProzent / 100));
  const gesamtersparnis = runde10(ersparnis + foerderungEur - wartungKosten);

  const jahre = Array.from({ length: 20 }, (_, i) => i + 1);
  const investitionen = jahre.map(() => kostenGesamt);

  const degradationsrate = parseFloat(solarrechnerBackendSettings.degradation) / 100;

  const ersparnisProJahr = jahre.map(j => {
    const faktor = Math.pow(1 - degradationsrate, j - 1);
    return gesamtersparnis * faktor * j;
  });

  const renditeArray = jahre.map((_, index) => {
    const faktor = Math.pow(1 - degradationsrate, index);
    const aktuelleErsparnis = gesamtersparnis * faktor;
    return (aktuelleErsparnis / kostenGesamt) * 100;
  });

  const durchschnittRendite = renditeArray.reduce((sum, r) => sum + r, 0) / renditeArray.length;
  let rendite = durchschnittRendite;

  const kumulierteErsparnis20Jahre = runde10(ersparnisProJahr.at(-1));
  const gewinnNach20Jahren = runde10(kumulierteErsparnis20Jahre - kostenGesamt);

  let kumulierteErsparnis = 0;
  let amortisationsJahr = 0;
  for (let j = 0; j < ersparnisProJahr.length; j++) {
    kumulierteErsparnis += ersparnisProJahr[j] - (ersparnisProJahr[j - 1] || 0);
    if (kumulierteErsparnis >= kostenGesamt) {
      amortisationsJahr = j + 1;
      break;
    }
  }

  document.getElementById("ergebnis").innerHTML = `
      <div class="table-wrapper">
      <table class="responsive-table">
        <tbody>
          <tr><td>${solarrechnerBackendSettings.texte.leistung}</td><td>${kWp.toFixed(2)} kWp</td></tr>
          <tr><td>${solarrechnerBackendSettings.texte.ertrag}</td><td>${ertrag.toLocaleString("de-DE")} kWh</td></tr>
          <tr><td>${solarrechnerBackendSettings.texte.eigenverbrauch}</td><td>${eigenverbrauch.toLocaleString("de-DE")} kWh</td></tr>
          <tr><td>${solarrechnerBackendSettings.texte.ersparnis}</td><td>${ersparnis.toLocaleString("de-DE")} € ${solarrechnerBackendSettings.jahr}</td></tr>
          <tr><td>${solarrechnerBackendSettings.texte.einspeise}</td><td>${foerderungEur.toLocaleString("de-DE")} € ${solarrechnerBackendSettings.jahr}</td></tr>
          <tr><td>${solarrechnerBackendSettings.texte.wartung}</td><td>${wartungKosten.toLocaleString("de-DE")} € ${solarrechnerBackendSettings.jahr}</td></tr>
          <tr><td>${solarrechnerBackendSettings.texte.gesamt}</td><td>${gesamtersparnis.toLocaleString("de-DE")} € ${solarrechnerBackendSettings.jahr}</td></tr>
          <tr><td>${solarrechnerBackendSettings.texte.autarkie}</td><td>${autarkie.toFixed(0)}%</td></tr>
          <tr><td>${solarrechnerBackendSettings.texte.co2}</td><td>${co2.toLocaleString("de-DE")} kg</td></tr>
          <tr><td>${solarrechnerBackendSettings.texte.kosten}</td><td>${kostenGesamt.toLocaleString("de-DE")} €</td></tr>
          <tr><td>${solarrechnerBackendSettings.texte.ersparnis20}</td><td>${kumulierteErsparnis20Jahre.toLocaleString("de-DE")} €</td></tr>
          <tr><td>${solarrechnerBackendSettings.texte.rendite}</td><td>${rendite.toFixed(2)} %</td></tr>
          <tr><td>${solarrechnerBackendSettings.texte.gewinn20}</td><td><strong>${gewinnNach20Jahren.toLocaleString("de-DE")} €</strong></td></tr>
          <tr><td>${solarrechnerBackendSettings.texte.amortisation}</td><td>${amortisationsJahr} ${solarrechnerBackendSettings.jahre}</td></tr>
        </tbody>
      </table>
    </div>
  `;

  if (chart) chart.destroy();
  chart = new Chart(document.getElementById('pvChart'), {
    type: 'doughnut',
    data: {
      labels: [
        solarrechnerBackendSettings?.pdftexte?.eigenverbrauch_label || 'Eigenverbrauch',
        solarrechnerBackendSettings?.pdftexte?.einspeisung_label || 'Einspeisung'
      ],
      datasets: [{
        label: solarrechnerBackendSettings?.pdftexte?.stromverteilung_label || 'Stromverteilung',
        data: [eigenverbrauch, einspeisung],
        backgroundColor: ['#4caf50', '#ff9800']
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false, // <-- erlaubt flexible Höhe
      aspectRatio: 1,             // 1 = quadratisch (Höhe = Breite)
      plugins: {
        legend: { position: 'bottom' },
        title: { display: true, text: solarrechnerBackendSettings?.pdftexte?.verbrauch_einspeisung || 'Verbrauch vs. Einspeisung' }
      }
    }
  });

  const jahrlabel = solarrechnerBackendSettings.pdftexte.jahr_label;
  const ctx = document.getElementById('lineChart').getContext('2d');

  if (lineChart) lineChart.destroy();
  lineChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels: jahre.map(j => `${jahrlabel} ${j}`),
      datasets: [
        {
          label: solarrechnerBackendSettings?.pdftexte?.kumulierte_ersparnis || 'Kumulierte Ersparnis (€)',
          data: ersparnisProJahr,
          borderColor: '#4caf50',
          backgroundColor: 'rgba(76, 175, 80, 0.2)',
          fill: true
        },
        {
          label: solarrechnerBackendSettings?.pdftexte?.investitionskosten || 'Investitionskosten',
          data: investitionen,
          borderColor: '#f44336',
          backgroundColor: 'rgba(244, 67, 54, 0.2)',
          fill: true
        },
        {
          label: solarrechnerBackendSettings?.texte?.rendite_label || 'Rendite (%)',
          data: renditeArray,
          borderColor: '#2196f3',
          backgroundColor: 'rgba(33, 150, 243, 0.2)',
          fill: false,
          yAxisID: 'y1'
        }
      ]
    },
    options: {
      responsive: true,
      plugins: {
        title: {
          display: true,
          text: solarrechnerBackendSettings?.pdftexte?.wirtschaftlichkeit20 || 'Wirtschaftlichkeit über 20 Jahre'
        }
      },
      scales: {
        y: {
          type: 'linear',
          position: 'left'
        },
        y1: {
          type: 'linear',
          position: 'right',
          min: 0,
          max: 15,
          grid: {
            drawOnChartArea: false
          },
          ticks: {
            callback: (value) => value + ' %'
          }
        }
      }
    }
  });
}
// -- WICHTIG: exportPDF steht außerhalb der Funktion berechne()! --

function exportPDF() {
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();

  // 1. Texte oben einfügen
  doc.setFontSize(20);
  const domain = window.location.hostname.toUpperCase();
  const titelMitDomain = (solarrechnerBackendSettings?.pdftexte?.titel || '') + ' ' + domain;
  doc.text(titelMitDomain, 10, 15);

  doc.setFontSize(10);
  doc.setTextColor(100);
  doc.text(solarrechnerBackendSettings?.pdftexte?.hinweis || '', 10, 25);

  // Zeichnet eine Line oberhalb der Ergebnisse
  doc.setDrawColor(180);
  doc.line(10, 28, 200, 28);

  doc.setFontSize(12);
  doc.setTextColor(0);

  let y = 35;

  // 2. Tabelle mit Ergebnissen einfügen
  const rows = Array.from(document.querySelectorAll('#ergebnis table tr'));
  rows.forEach(row => {
    const cells = row.querySelectorAll('td');
    if (cells.length === 2) {
      const label = cells[0].innerText.trim();
      const value = cells[1].innerText.trim();
      doc.text(label, 15, y);
      doc.text(value, 115, y, { align: 'right' });
      y += 6;
    }
  });

  // Zeichnet eine Linie unterhalb der Ergebnise
  doc.line(10, y-2, 200, y-2); 
  doc.text(solarrechnerBackendSettings?.pdftexte?.kontakt || '', 10, y+3);

  // 3. WICHTIG: Charts aktualisieren, damit richtige Sprache erscheint
  if (chart) chart.update();
  if (lineChart) lineChart.update();

  // 4. Charts als Bilder speichern
  const pvCanvas = document.getElementById("pvChart");
  const lineCanvas = document.getElementById("lineChart");

  const pvImg = pvCanvas.toDataURL("image/png");
  const lineImg = lineCanvas.toDataURL("image/png");

  // 5. Neue Seite für Diagramme
  doc.addPage();
  doc.setFontSize(14);
  doc.text(solarrechnerBackendSettings?.pdftexte?.diagrammTitel || '', 10, 10);
  doc.line(10, 13, 200, 13);

  const donutRatio = pvCanvas.width / pvCanvas.height;
  const donutWidth = 120;
  const donutHeight = donutWidth / donutRatio;
  
  doc.addImage(pvImg, 'PNG', 40, 20, donutWidth, donutHeight);
  
  doc.line(10, 130, 200, 130);
  doc.addImage(lineImg, 'PNG', 10, 150, 180, 100);

  // 6. Hinweis auf Degradation
  doc.setFontSize(9);
  const degradationHinweis = `${solarrechnerBackendSettings?.pdftexte?.degradHinweis || 'Berücksichtigte Degradation'}: ${solarrechnerBackendSettings?.degradation}%`;
  doc.text(degradationHinweis, 10, doc.internal.pageSize.height - 10);

  // 7. Fertig: PDF speichern
  doc.save("PV-Ergebnis.pdf");
}
