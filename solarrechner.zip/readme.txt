=== Solar Calculator ===
* Contributor:       HBurk Consulting
* Tags:              solar, photovoltaic, calculator, pv, energy
* Requires at least: 6.0
* Tested up to:      6.8
* Requires PHP:      7.2
* Stable tag:        1.0.4
* License:           GPLv2 or later
* License URI:       https://www.gnu.org/licenses/gpl-2.0.html

A modern tool to support websites promoting solar energy. Helps households estimate the yield, autonomy, and payback of a potential PV system.
The tool is free of charge and is intended to support volunteer citizen solar advisors.

== Description ==

This plugin lets you calculate the yield, self-sufficiency, and payback time of a photovoltaic (PV) system directly on your WordPress site.

It includes:

- A clear, responsive frontend calculator
- Customizable backend settings (regional values, cost presets)
- Multilingual support (WPML, Polylang, etc.)
- Realistic solar data for accurate estimations
- Battery and installation cost calculations
- Language-ready template with .po/.mo files (DE, GR, IT, EN, ES, FR)

Ideal for solar companies, energy advisors, or eco-conscious website owners.
A small "HBurk" link inside the calculator refers to the author's website as a non-intrusive credit.

Made in Germany – optimized for European users.

== Installation ==

1. Upload the plugin to the `/wp-content/plugins/` directory.
2. Activate it via the 'Plugins' menu in WordPress.
3. Navigate to the settings panel to adjust base values if needed, save once.
4. Inlude shortcode [solarrechner] at your page or post.

== Changelog ==

= 1.0.4 =
* French and Italiano language added
* the charts are now translated into the respective languages
* the amortization calculation is now more realistic

= 1.0.3 =
* Improved calculation of module degradation
* Show the expected profit after 20 years
* Show the total investment including battery and maintenance costs

= 1.0.2 =
* Simplified user interface in the frontend
* Revised admin page in the backend to enter the required parameters
* User selectable language selection in the frontend

= 1.0.1 =
* Improved language integration
* Minor frontend adjustments

= 1.0 =
* Initial release

== Screenshots ==
1. Solar calculator frontend in action
2. Backend configuration (custom values, defaults)

== Developer Info ==

Plugin file structure:

/wp-content/plugins/
└── solarrechner/
    ├── solarrechner.php              ← Main plugin file
    ├── assets/
    │   ├── solarrechner.css          ← Frontend styles
    │   ├── solarrechner.js           ← Calculator logic
    │   └── js/
    │       └── chart.js
    │       └── jspdf.umd.min.js
    ├── flags/
    │	├── de.png
    │	├── en.png
    │	├── es.png
    │	├── fr.png
    │	└── it.png
    ├── includes/
    │   └── functions.php             ← Backend logic: localization, settings
    ├── languages/
    │   ├── solarrechner-de_DE.mo/.po
    │   ├── solarrechner-en_US.mo/.po
    │   ├── solarrechner-es_ES.mo/.po
    │   ├── solarrechner-fr_FR.mo/.po
    │   └── solarrechner-el_GR.mo/.po
    └── templates/
        └── solarrechner-frontend-i18n.php ← HTML/JS template with language support
