<?php
function solarrechner_zugriff_zaehlen()
{
    $zaehler = get_option('solarrechner_counter', 0);
    $zaehler++;
    update_option('solarrechner_counter', $zaehler);
    wp_send_json_success(['count' => $zaehler]);
}
add_action('wp_ajax_solarrechner_count', 'solarrechner_zugriff_zaehlen');
add_action('wp_ajax_nopriv_solarrechner_count', 'solarrechner_zugriff_zaehlen');

add_action('rest_api_init', function () {
    register_rest_route('solarrechner/v1', '/texte', [
        'methods' => 'GET',
        'callback' => 'solarrechner_lade_texte',
    ]);
});

add_action('after_setup_theme', function () {
    if (isset($_GET['lang'])) {
        $desired_locale = sanitize_text_field($_GET['lang']);

        // Nur erlaubte Sprachen zulassen (Sicherheit!)
        $available_locales = ['de_DE', 'el_GR', 'it_IT', 'en_US', 'es_ES', 'fr_FR'];
        $map = ['de' => 'de_DE', 'el' => 'el_GR', 'it' => 'it_IT', 'en' => 'en_US', 'es' => 'es_ES', 'fr' => 'fr_FR'];

        if (array_key_exists($desired_locale, $map) && in_array($map[$desired_locale], $available_locales)) {
            switch_to_locale($map[$desired_locale]);
            // Optional: Locale global setzen
            global $locale;
            $locale = $map[$desired_locale];
        }
    }
});


function solarrechner_enqueue_assets()
{
    wp_enqueue_style('solarrechner-css', plugin_dir_url(__DIR__) . 'assets/solarrechner.css');

    wp_enqueue_script(
        'chart-js',
        plugins_url('assets/js/chart.js', dirname(__FILE__)),
        [],
        null,
        true
    );
    wp_enqueue_script(
        'jspdf',
        plugins_url('assets/js/jspdf.umd.min.js', dirname(__FILE__)),
        [],
        null,
        true
    );
    wp_enqueue_script('solarrechner-js', plugin_dir_url(__DIR__) . 'assets/solarrechner_final_bereinigt.js', ['chart-js', 'jspdf'], null, true);

    $eigenverbrauch_werte = [
        '0' => 0.3,
        '5' => 0.4,
        '7.5' => 0.5,
        '10.0' => 0.6,
        '12.5' => 0.7,
        '15.0' => 0.8
    ];

    wp_localize_script('solarrechner-js', 'solarrechnerBackendSettings', [
        'qmkwp' => get_option('solarrechner_qmkwp', 5),
        'erstellungskosten' => get_option('solarrechner_kosten_kwp', 1300),
        'spezifischerErtrag' => get_option('solarrechner_spezifischerErtrag', 1000),
        'wartung' => get_option('solarrechner_wartung', 0.45),
        'batteriekosten' => get_option('solarrechner_batteriekosten', 500),
        'jahr' => __('pro Jahr', 'solarrechner') ?: 'pro Jahr',
        'jahre' => __('Jahre', 'solarrechner') ?: 'Jahre',
        'degradation' => get_option('solarrechner_degradation'),
        'einspeiseverguetung' => get_option('solarrechner_einspeiseverguetung'), // 👈 Das ist der wichtige Eintrag!        
        'tooltipQmkwp' => __('Quadratmeter je kWp installierter Leistung', 'solarrechner'),
        'tooltipEinspeise' => __('Einspeisevergütung nach EEG', 'solarrechner'),
        'tooltipdachflaeche' => __('Verfügbare Fläche für Solarmodule, Einschränkungen wie Dachfenster Dachgauben und Schornstein bitte abziehen', 'solarrechner'),

        'eigenverbrauchsanteile' => $eigenverbrauch_werte,

        'pdftexte' => [
            'titel' => __('Ergebnis der PV-Berechnung von:', 'solarrechner'),
            'hinweis' => __('Die Werte sind gerundet und grob überschlagen, bitte fordern Sie eine detalierte Beratung zu Ihrem Projekt an.', 'solarrechner'),
            'diagrammTitel' => __('Diagramme zur PV-Berechnung', 'solarrechner'),
            'kontakt' => __('Beratung anfordern via e-Mail: Info@bsb-heppenheim.de', 'solarrechner'),
            'degradHinweis' => __('Berücksichtig wurde eine Degradation in der Höhe von:', 'solarrechner'),
            'kumulierte_ersparnis' => __('Kumulierte Ersparnis (€)', 'solarrechner'),
            'wirtschaftlichkeit20' => __('Wirtschaftlichkeit über 20 Jahre', 'solarrechner'),
            'verbrauch_einspeisung' => __('Verbrauch vs. Einspeisung', 'solarrechner'),
            'eigenverbrauch_label' => __('Eigenverbrauch', 'solarrechner'),
            'einspeisung_label' => __('Einspeisung', 'solarrechner'),
            'stromverteilung_label' => __('Einspeisung', 'solarrechner'), // <== da ist noch ein Fehler  ???? !!!!!!!!!!!!!!!!!!!!!!!!!!!!
            'rendite_label' => __('Rendite:', 'solarrechner') ?: 'Rendite',
            'investitionskosten' => __('Investitionskosten (€)', 'solarrechner'),
            'jahr_label' => __('Jahr', 'solarrechner'),
        ],
        'texte' => [
            'leistung' => __('Installierbare Leistung:', 'solarrechner'),
            'ertrag' => __('Jahresertrag:', 'solarrechner'),
            'eigenverbrauch' => __('Eigenverbrauch:', 'solarrechner'),
            'ersparnis' => __('Stromkosten-Ersparnis:', 'solarrechner'),
            'einspeise' => __('Einspeisevergütung:', 'solarrechner'),
            'wartung' => __('Abzgl. Instandhaltung:', 'solarrechner'),
            'gesamt' => __('Gesamtersparnis:', 'solarrechner'),
            'autarkie' => __('Autarkiegrad:', 'solarrechner'),
            'co2' => __('CO₂-Einsparung:', 'solarrechner'),
            'kosten' => __('Investitionskosten:', 'solarrechner'),
            'ersparnis20' => __('Ersparnis in 20 Jahren:', 'solarrechner'),
            'rendite' => __('&#x2300; Rendite:', 'solarrechner') ?: 'Rendite',
            'gewinn20' => __('Gewinn nach 20 Jahren:', 'solarrechner'),
            'amortisation' => __('Amortisationszeit:', 'solarrechner')
        ]
    ]);
}
add_action('wp_enqueue_scripts', 'solarrechner_enqueue_assets');
