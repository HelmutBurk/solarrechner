<?php

/**
 * Plugin Name: Solar Calculator
 * Plugin URI: https://www.mehr-geld-sparen.de
 * Description: Calculate yield, self-sufficiency, and payback of a PV system. Includes backend settings and multilingual support.
 * Version: 1.0.4
 * Author: Helmut Burk
 * Author URI: https://www.mehr-geld-sparen.de
 * Requires at least: 6.0
 * Tested up to: 6.8
 * Requires PHP: 7.2
 * License: GPL2
 * Text Domain: solarrechner
 * Domain Path: /languages
 */

// Sicherheitscheck
if (!defined('ABSPATH')) exit;

require_once plugin_dir_path(__FILE__) . 'includes/functions_final.php';
require_once plugin_dir_path(__FILE__) . 'admin/solarrechner-settings.php';


// Konstanten definieren
define('SOLARRECHNER_VERSION', '1.0.1');
define('SOLARRECHNER_PATH', plugin_dir_path(__FILE__));
define('SOLARRECHNER_URL', plugin_dir_url(__FILE__));

add_action('wp_enqueue_scripts', 'solarrechner_enqueue_scripts');
add_action('wp_enqueue_scripts', 'solarrechner_enqueue_assets');
//add_action('plugins_loaded', 'solarrechner_load_textdomain');

function solarrechner_enqueue_styles()
{
  wp_enqueue_style(
    'solarrechner-style',
    plugin_dir_url(__FILE__) . 'assets/solarrechner.css',
    array(),
    '1.0.3'
  );
}
add_action('wp_enqueue_scripts', 'solarrechner_enqueue_styles');

// Backend-Menü hinzufügen
add_action('admin_menu', function () {
  add_menu_page(
    __('Solarrechner', 'solarrechner'),
    __('Solarrechner', 'solarrechner'),
    'manage_options',
    'solarrechner-settings',
    'solarrechner_settings_page',
    'dashicons-lightbulb',
    80
  );
});

// Einstellungen registrieren
add_action('admin_init', function () {
  register_setting('solarrechner_settings_group', 'solarrechner_einspeiseverguetung', array(
    'sanitize_callback' => 'sanitize_text_field'
  ));
  register_setting('solarrechner_settings_group', 'solarrechner_qm_pro_kwp', array(
    'sanitize_callback' => 'sanitize_text_field'
  ));
  register_setting('solarrechner_settings_group', 'solarrechner_tooltip_einspeise', array(
    'sanitize_callback' => 'sanitize_text_field'
  ));
  register_setting('solarrechner_settings_group', 'solarrechner_tooltip_qmkwp', array(
    'sanitize_callback' => 'sanitize_text_field'
  ));
});


// Frontend-Skripte nur bei Bedarf laden
function solarrechner_enqueue_scripts()
{
  if (!is_singular()) return;
  global $post;
  if (has_shortcode($post->post_content, 'solarrechner')) {
    wp_enqueue_script('chart-js', plugin_dir_url(__FILE__) . '../assets/js/chart.min.js', [], null, true);
    wp_enqueue_script('jspdf', plugin_dir_url(__FILE__) . '../assets/js/jspdf.umd.min.js', [], null, true);
  }
}

// Shortcode einbinden
add_shortcode('solarrechner', function () {
  ob_start();
  include SOLARRECHNER_PATH . 'templates/solarrechner-frontend-i18n.php';
  return ob_get_clean();
});
