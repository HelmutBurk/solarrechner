<?php

/** Template: Solarrechner_frontend-i18n.php  *****
 ** Version: 1.0.4                            *****
 ** ========================================= *****
 **
 ** Version: 1.0.34                           *****
 ** Hinweis: Chart.js und jsPDF werden über wpesc_html_enqueue_script eingebunden
 ** Das Stylesheet wird über wpesc_html_enqueue_style aus solarrechner.css geladen
 */
?>

<div class="solarrechner-wrapper">
  <div class="language-switcher" style="margin-bottom: 1em;">
    <a href="?lang=de">
      <img src="<?php echo esc_url(plugin_dir_url(dirname(__FILE__)) . 'flags/de.png'); ?>"
        alt="<?php echo esc_attr__('Deutsch', 'solarrechner'); ?>"
        title="<?php echo esc_attr__('Deutsch', 'solarrechner'); ?>"
        style="cursor:pointer; width:24px; margin-right:8px;">
    </a>
    <a href="?lang=it">
      <img src="<?php echo esc_url(plugin_dir_url(dirname(__FILE__)) . 'flags/it.png'); ?>"
        alt="<?php echo esc_attr__('Italiano', 'solarrechner'); ?>"
        title="<?php echo esc_attr__('Italiano', 'solarrechner'); ?>"
        style="cursor:pointer; width:24px; margin-right:8px;">
    </a>
    <a href="?lang=el">
      <img src="<?php echo esc_url(plugin_dir_url(dirname(__FILE__)) . 'flags/el.png'); ?>"
        alt="<?php echo esc_attr__('ελληνικά', 'solarrechner'); ?>"
        title="<?php echo esc_attr__('ελληνικά', 'solarrechner'); ?>"
        style="cursor:pointer; width:24px; margin-right:8px;">
    </a>
    <a href="?lang=en">
      <img src="<?php echo esc_url(plugin_dir_url(dirname(__FILE__)) . 'flags/us.png'); ?>"
        alt="<?php echo esc_attr__('English', 'solarrechner'); ?>"
        title="<?php echo esc_attr__('English', 'solarrechner'); ?>"
        style="cursor:pointer; width:24px; margin-right:8px;">
    </a>
    <a href="?lang=es">
      <img src="<?php echo esc_url(plugin_dir_url(dirname(__FILE__)) . 'flags/es.png'); ?>"
        alt="<?php echo esc_attr__('Español', 'solarrechner'); ?>"
        title="<?php echo esc_attr__('Español', 'solarrechner'); ?>"
        style="cursor:pointer; width:24px;">
    </a>
    <a href="?lang=fr">
      <img src="<?php echo esc_url(plugin_dir_url(dirname(__FILE__)) . 'flags/fr.png'); ?>"
        alt="<?php echo esc_attr__('Französisch', 'solarrechner'); ?>"
        title="<?php echo esc_attr__('Fanzösisch', 'solarrechner'); ?>"
        style="cursor:pointer; width:24px;">
    </a>
  </div>

  <div class="solar-form-container">
    <h2 class="solar-title"><?php esc_html_e('Solarrechner – PV Anlage selbst berechnen', 'solarrechner'); ?></h2>
    <table class="solar-input-table">
      <tr><!--
        <td>
          <label for="batteriekosten"><?php esc_html_e('Batterie-Kosten', 'solarrechner'); ?> <span title="<?php esc_html_e('Preis der Batterie : kWh der Batterie', 'solarrechner'); ?>">ℹ️</span></label>
          <select id="batteriekosten">
            <option value="700"><?php esc_html_e('700 Euro bei 3 bis 5 kWh Batterieleistung', 'solarrechner'); ?></option>
            <option value="600"><?php esc_html_e('600 Euro bei 7 bis 10 kWh Batterieleistung', 'solarrechner'); ?></option>
            <option value="500"><?php esc_html_e('500 Euro bei 10 und mehr kWh Batterieleistung', 'solarrechner'); ?></option>
          </select>
        </td> -->
      </tr>
      <tr>
        <td>
          <label for="dachflaeche"><?php esc_html_e('Dachfläche (m²)', 'solarrechner'); ?> <span title="<?php esc_html_e('Verfügbare Fläche für Solarmodule, Einschränkungen wie Dachfenster, Dachgauben und Schornstein bitte abziehen', 'solarrechner'); ?>">ℹ️</span></label>
          <input type="number" id="dachflaeche" value="30" step="0.1" max="350" min="5">
        </td>
        <td>
          <label for="ausrichtung"><?php esc_html_e('Dachausrichtung', 'solarrechner'); ?> <span title="<?php esc_html_e('Ausrichtung der Dachfläche mit dem Hauptanteil an belegbarer Dachfläche', 'solarrechner'); ?>">ℹ️</span></label>
          <select id="ausrichtung">
            <option value="1"><?php esc_html_e('Süd', 'solarrechner'); ?></option>
            <option value="0.95"><?php esc_html_e('Südost/Südwest', 'solarrechner'); ?></option>
            <option value="0.90"><?php esc_html_e('Ost/West', 'solarrechner'); ?></option>
          </select>
        </td>
      </tr>
      <tr>
        <td>
          <label for="neigung"><?php esc_html_e('Dachneigung (°)', 'solarrechner'); ?> <span title="<?php esc_html_e('Hauptausrichtung der belegbaren Dachfläche', 'solarrechner'); ?>">ℹ️</span></label>
          <input type="number" id="neigung" value="30">
        </td>
        <td>
          <label for="verbrauch"><?php esc_html_e('Stromverbrauch (kWh/Jahr)', 'solarrechner'); ?> <span title="<?php esc_html_e('Jährlicher Stromverbrauch im Haushalt', 'solarrechner'); ?>">ℹ️</span></label>
          <input type="number" id="verbrauch" value="3500">
        </td>
      </tr>
      <tr>
        <td>
          <label for="strompreis"><?php esc_html_e('Strompreis (ct/kWh)', 'solarrechner'); ?> <span title="<?php esc_html_e('Aktueller Bruttoarbeitspreis aus Ihrem Stromliefervertrag', 'solarrechner'); ?>">ℹ️</span></label>
          <input type="number" id="strompreis" value="38" min="15" max="80">
        </td>
        <td>
          <label for="batterie"><?php esc_html_e('Batteriespeicher erwünscht?', 'solarrechner'); ?> <span title="<?php esc_html_e('Ein Batteriespeicher verdoppelt den Anteil des erzeugten Stroms, den Sie selbst verbrauchen und reduziert damit ihre Abhängigkeit vom Strompreis des Versorgers', 'solarrechner'); ?>">ℹ️</span></label>
          <select id="batterie">
            <option value="0"><?php esc_html_e('Nein', 'solarrechner'); ?></option>
            <option value="5"><?php esc_html_e('Ja – 5 kWh', 'solarrechner'); ?></option>
            <option value="7.5"><?php esc_html_e('Ja – 7,5 kWh', 'solarrechner'); ?></option>
            <option value="10"><?php esc_html_e('Ja – 10 kWh', 'solarrechner'); ?></option>
            <option value="12.5"><?php esc_html_e('Ja – 12,5 kWh', 'solarrechner'); ?></option>
            <option value="15"><?php esc_html_e('Ja – 15 kWh', 'solarrechner'); ?></option>
          </select>
        </td>
      </tr>
    </table>
    <p>
      <button class="btn-solar" onclick="berechne()"><?php esc_html_e('Berechnen', 'solarrechner'); ?></button>
      <button class="btn-solar" onclick="exportPDF()"><?php esc_html_e('Ergebnis als PDF', 'solarrechner'); ?></button>
      <?php
      printf(
        /* translators: %s ist der Link zu HBurk Consulting */
        esc_html__('Copyright © by %s', 'solarrechner'),
        '<a href="' . esc_url('https://www.mehr-geld-sparen.de') . '" target="_blank">HBurk</a>'
      );
      ?>
    </p>
    <p class="solarrechner-counter">
      <?php
      printf(
        /* translators: %d steht für die Anzahl der bisherigen Nutzungen des Rechners */
        esc_html__('Der Rechner wurde bisher %d Mal genutzt.', 'solarrechner'),
        intval(get_option('solarrechner_counter', 0))
      );
      ?>
    </p>

    <div class="error-message" id="error"></div>

  </div>

  <div class="responsive-columns">
    <div class="responsive-column">
      <div id="ergebnis"></div>
    </div>
    <div class="responsive-column chart-wrapper">
      <canvas id="pvChart"></canvas>
    </div>
  </div>
  <div class="full-width-canvas">
    <canvas id="lineChart"></canvas>
  </div>