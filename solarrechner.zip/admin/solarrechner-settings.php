<?php

/** Template: Solarrechner_settings.php  *****
 ** define input fields,                 *****
 ** render admin page                    *****
 ** Version: 1.0.4                       *****
 ** ==================================== *****
 */


#
// Sicherheitscheck
if (!defined('ABSPATH')) {
    exit;
}

// Menü-Eintrag hinzufügen
add_action('admin_menu', function () {
    add_options_page(
        __('Solarrechner Einstellungen', 'solarrechner'),
        'Solarrechner',
        'manage_options',
        'solarrechner-settings',
        'solarrechner_settings_page'
    );
});

/**
 * Wandelt eine Eingabe in eine Float-Zahl um.
 *
 * @param mixed $input Eingabewert.
 * @return float
 */
function solarrechner_sanitize_float($input)
{
    return floatval($input);
}


// Eingabefelder registrieren
add_action('admin_init', function () {
    register_setting('solarrechner_settings_group', 'solarrechner_einspeiseverguetung', array(
        'sanitize_callback' => 'floatval'
    ));

    register_setting('solarrechner_settings_group', 'solarrechner_qmkwp', array(
        'sanitize_callback' => 'floatval'
    ));

    register_setting('solarrechner_settings_group', 'solarrechner_degradation', array(
        'sanitize_callback' => 'floatval'
    ));
    register_setting('solarrechner_settings_group', 'solarrechner_kosten_kwp', array(
        'sanitize_callback' => 'floatval'
    ));
    register_setting('solarrechner_settings_group', 'solarrechner_spezifischerErtrag', array(
        'sanitize_callback' => 'floatval'
    ));
    register_setting('solarrechner_settings_group', 'solarrechner_wartung', array(
        'sanitize_callback' => 'floatval'
    ));
    register_setting('solarrechner_settings_group', 'solarrechner_batteriekosten', array(
        'sanitize_callback' => 'floatval'
    ));
});


// Seite rendern
function solarrechner_settings_page()
{
?>
    <div class="wrap">
        <h1><?php esc_html_e('Solarrechner Einstellungen', 'solarrechner'); ?></h1>


        <p class="solarrechner-counter">
            <?php esc_html_e('Der Rechner wurde bisher', 'solarrechner'); ?>
            <strong><?php echo intval(get_option('solarrechner_counter', 0)); ?></strong>
            <?php esc_html_e('Mal genutzt.', 'solarrechner'); ?>
        </p>

        <form method="post" action="options.php">
            <?php settings_fields('solarrechner_settings_group'); ?>
            <?php do_settings_sections('solarrechner_settings_group'); ?>
            <table class="form-table">
                <tr>
                    <th scope="row"><?php esc_html_e('Einspeisevergütung (ct/kWh)', 'solarrechner'); ?></th>
                    <td>
                        <input type="number" step="0.01" name="solarrechner_einspeiseverguetung" value="<?php echo esc_attr(get_option('solarrechner_einspeiseverguetung', 7.94)); ?>">
                        <p class="description">
                            <?php esc_html_e('Einspeisevergütung zur Zeit (2025 Germany) 7,94 ct', 'solarrechner'); ?>
                        </p>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row"><?php esc_html_e('Quadratmeter je kWp', 'solarrechner'); ?></th>
                    <td>
                        <input type="number" step="0.1" min="1.0" max="6.0" name="solarrechner_qmkwp" value="<?php echo esc_attr(get_option('solarrechner_qmkwp', 5)); ?>" />
                        <p class="description"><?php esc_html_e('bei einem 400 Watt Modul 4,7 bis 5,5 d.h. 4-6', 'solarrechner'); ?></p>
                    </td>
                </tr>
                <tr>
                    <th scope="row"><?php esc_html_e('Leistungsminderung pro Jahr (%)', 'solarrechner'); ?></th>
                    <td>
                        <input type="number" step="0.10" min="0.10" max="1.20" name="solarrechner_degradation" value="<?php echo esc_attr(get_option('solarrechner_degradation', 0.2)); ?>">
                        <p class="description"><?php esc_html_e('Typisch sind Werte für die Degradation zwischen 0.3 und 1.0 %.', 'solarrechner'); ?></p>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row"><?php esc_html_e('Erstellungskosten pro kWp (€)', 'solarrechner'); ?></th>
                    <td>
                        <input type="number" step="100" name="solarrechner_kosten_kwp" value="<?php echo esc_attr(get_option('solarrechner_kosten_kwp', 1600)); ?>" />
                        <p class="description"><?php esc_html_e('Angebotspreis geteilt durch die kWp der Anlage (small=1800, medium=1400)', 'solarrechner'); ?></p>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row"><?php esc_html_e('spezifischer Ertrag je kwp', 'solarrechner'); ?></th>
                    <td>
                        <input type="number" step="50" name="solarrechner_spezifischerErtrag" value="<?php echo esc_attr(get_option('solarrechner_spezifischerErtrag', 1000)); ?>" />
                        <p class="description"><?php esc_html_e('Ertrag je kWp installierter Leistung in Ihrer Region (Südhessen=1000 München=1200', 'solarrechner'); ?></p>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row"><?php esc_html_e('Wartungskosten in Prozent vom Gesamtpreis', 'solarrechner'); ?></th>
                    <td>
                        <input type="number" min="0.20" max="2.00" step="0.10" name="solarrechner_wartung" value="<?php echo esc_attr(get_option('solarrechner_wartung', 1.5)); ?>" />
                        <p class="description"><?php esc_html_e('Jährliche Instandhaltungskosten (% der Investition)', 'solarrechner'); ?></p>
                        <p class="description"><?php esc_html_e('small= 1,50 medium= 0,75 large= 0,30', 'solarrechner'); ?></p>
                    </td>
                </tr>
                <tr valign="top">
                    <th scope="row"><?php esc_html_e('Batteriekosten (€ pro kWh)', 'solarrechner'); ?></th>
                    <td>
                        <input type="number" name="solarrechner_batteriekosten" step="10" value="<?php echo esc_attr(get_option('solarrechner_batteriekosten', 500)); ?>" />
                        <p class="description"><?php esc_html_e('Durchschnittliche Batteriekosten (500-600-700) in Euro pro kWh', 'solarrechner'); ?></p>
                    </td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
<?php
}
